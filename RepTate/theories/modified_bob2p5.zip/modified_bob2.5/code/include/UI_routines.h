// rc
extern int splitrcopt(char *, char *, char *);
extern int getline(FILE *, char *);
extern void removewhitespace(char *);

extern int rcread(void);
extern void rcdecide(char *, char *);
