exetern void warnmsgs(int );
extern void warnmsgstring(int, char *);
