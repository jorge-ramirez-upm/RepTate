// Random number utilities for bob
extern double gasdev(void);
extern double armlen_gaussian(double, double);
extern double armlen_lognormal(double, double);
extern double armlen_semiliving(double, double);
extern double flory_distb(double);
extern double gammln(double);
extern double poisson(double);
extern void rand_on_line(double, int, double *);
