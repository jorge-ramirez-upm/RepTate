extern int nlin_relaxing_arm(int, double);
extern double interp_rouse_time(double *, double *, int, double);
extern int find_rate_indx(double);
extern void calc_free_arm_phi_held(int);
extern void reptate_nlin_sngl_arm(int);
extern void init_var_nlin(void);

