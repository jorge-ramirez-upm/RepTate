extern double gpc_calc_mass(int);
extern double gpc_calc_wtfrac(int);
extern int gpc_num_br(int);
extern double gpc_calc_gfac(int);
extern void gpchist(int, int, int, double *, double *, double *, double *);
extern void dumpgpcres(int, int, double *, double *, double *, double, double);

